How to run the system: 
in the project directory in your terminal of choice, run 'python hw4.py [pos file] [plain words file]'
ex. 'python hw4.py test.pos test.words'
